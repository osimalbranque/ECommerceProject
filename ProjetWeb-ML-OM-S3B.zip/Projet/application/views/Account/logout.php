        <section>
            <h2>Déconnexion</h2>
            
            <p>Au revoir et à bientôt sur les ClasicoFolies !</p>
        </section>
    </body>
</html>
