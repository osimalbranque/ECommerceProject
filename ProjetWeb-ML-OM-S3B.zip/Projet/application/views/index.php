        <div class="container">	
	<img src="background.jpg" alt="First slide">
        </img>
            <?php echo base_url(); ?>
        </div>
    </body>
</html>
