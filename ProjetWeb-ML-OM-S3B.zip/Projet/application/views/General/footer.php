<footer>
        <p>
            © 2015 IUT<strong> Informatique de Bordeaux</strong><br>
            Site web réalisé par Marco Lugustiano et Osiris Malbranque
	</p>  
</footer>
</div><!-- Fin du container-fluid -->
</body>
</html>
