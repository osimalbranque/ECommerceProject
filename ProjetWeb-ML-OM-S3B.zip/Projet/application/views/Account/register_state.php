        <section>
            <h3>Votre inscription a bien été prise en compte.</h3>
        
        <p><?php echo anchor('index.php/Account/Register', 'Il y a des erreurs sur le formulaire'); ?></p>
        </section>
    </body>
</html>
