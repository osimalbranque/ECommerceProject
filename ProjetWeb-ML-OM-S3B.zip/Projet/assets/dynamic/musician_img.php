<?php
header("Content-Type: image/jpeg");


?>