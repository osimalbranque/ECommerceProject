        <section>
            Achat confirmé.<br>
            <a href="<?php echo site_url('index.php'); ?>"><button class="btn btn-default">Retour à l'accueil</button></a>
        </section>
